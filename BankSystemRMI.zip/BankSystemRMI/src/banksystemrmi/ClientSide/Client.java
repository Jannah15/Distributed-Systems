/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banksystemrmi.ClientSide;

import java.io.Serializable;

/**
 *
 * @author Jannah
 */
public class Client implements Serializable{
    String username;
    String accountNo;
    String pin;
    String region;
    float balance;

    public Client(String username, String accountNo, String pin, String region, float balance) {
        this.username = username;
        this.accountNo = accountNo;
        this.pin = pin;
        this.region = region;
        this.balance = balance;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Client{" + "username=" + username + ", accountNo=" + accountNo + ", pin=" + pin + ", region=" + region + ", balance=" + balance + '}';
    }
    
    
}
