/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banksystemrmi.Masters;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Jannah
 */
public class MasterServer2 {

    static Master2_GUI mGUI;

    public static void main(String[] args) throws Exception {

        Registry r = LocateRegistry.createRegistry(1100);

        Master2Imp m2 = new Master2Imp();

        r.rebind("Master Server 2", m2);
        System.out.println("Master Server 2 Connected");

//        mGUI = new Master2_GUI();
//        mGUI.setVisible(true);
    }
}
