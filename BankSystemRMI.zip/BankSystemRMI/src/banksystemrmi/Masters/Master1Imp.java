/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banksystemrmi.Masters;

import Workers.WorkerServer;
import static banksystemrmi.ClientSide.BankClient_GUI.request;
import banksystemrmi.ClientSide.Client;
import static banksystemrmi.Masters.Master2Imp.clients2;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.rmi.registry.Registry;

/**
 *
 * @author Jannah
 */
public class Master1Imp extends UnicastRemoteObject implements MasterServer {

    public static ArrayList<Client> clients1;
    public static ArrayList<Client> clients2Copy;
    //static Master1GUI m1GUI;

    public Master1Imp() throws RemoteException {
        clients1 = new ArrayList<>();
        clients1.add(new Client("Ahmed", "10349706", "1234", "Sharm El Sheikh", 20000));
        clients1.add(new Client("Nada", "12840237", "5678", "Ghurgada", 30000));
        clients1.add(new Client("Omar", "13085224", "9101", "El Gouna", 25000));
        clients2Copy = clients2;
        
    }

    @Override
    public Client getClient(String name, String PIN) throws RemoteException {
        for (int i = 0; i < clients1.size(); i++) {
            Client c1 = clients1.get(i);
            if (c1.getUsername().equals(name) && c1.getPin().equals(PIN)) {
                return c1;
            }
        }
        return null;

    }
    
    @Override
    public Client deposit(Client c, float amount)throws RemoteException{
        String region = c.getRegion();
        Registry r;
        WorkerServer obj;
        try {
        switch(region){
            case "Sharm El Sheikh":
                r = LocateRegistry.getRegistry("localhost", 1200);
                obj = (WorkerServer) r.lookup("Sharm El Sheikh Worker Server");
                c = obj.Deposit(amount);
                break;
            case "Ghurgada":
                r = LocateRegistry.getRegistry("localhost", 1400);
                obj = (WorkerServer) r.lookup("Ghurgada Worker Server");
                c = obj.Deposit(amount);
                break;
            case "El Gouna":
                r = LocateRegistry.getRegistry("localhost", 1700);
                obj = (WorkerServer) r.lookup("El Gouna Worker Server");
                c = obj.Deposit(amount);
                break;
            default:
                System.out.println("Server not found");
                
        }
        }catch(Exception e){
            System.out.println(e);
        }
        return c;
    }
    
    @Override
    public Client withdraw(Client c, float amount)throws RemoteException{
        String region = c.getRegion();
        Registry r;
        WorkerServer obj;
        try {
        switch(region){
            case "Sharm El Sheikh":
                r = LocateRegistry.getRegistry("localhost", 1200);
                obj = (WorkerServer) r.lookup("Sharm El Sheikh Worker Server");
                c = obj.Withdraw(amount);
                break;
            case "Ghurgada":
                r = LocateRegistry.getRegistry("localhost", 1400);
                obj = (WorkerServer) r.lookup("Ghurgada Worker Server");
                c = obj.Withdraw(amount);
                break;
            case "El Gouna":
                r = LocateRegistry.getRegistry("localhost", 1700);
                obj = (WorkerServer) r.lookup("El Gouna Worker Server");
                c = obj.Withdraw(amount);
                break;
            default:
                System.out.println("Server not found");
                
        }
        }catch(Exception e){
            System.out.println(e);
        }
        return c;
    }
    
    @Override
    public float checkBalance(Client c)throws RemoteException{
        String region = c.getRegion();
        Registry r;
        WorkerServer obj;
        float b;
        try {
        switch(region){
            case "Sharm El Sheikh":
                r = LocateRegistry.getRegistry("localhost", 1200);
                obj = (WorkerServer) r.lookup("Sharm El Sheikh Worker Server");
                b = obj.CheckBalance();
                break;
            case "Ghurgada":
                r = LocateRegistry.getRegistry("localhost", 1400);
                obj = (WorkerServer) r.lookup("Ghurgada Worker Server");
                b = obj.CheckBalance();
                break;
            case "El Gouna":
                r = LocateRegistry.getRegistry("localhost", 1700);
                obj = (WorkerServer) r.lookup("El Gouna Worker Server");
                b = obj.CheckBalance();
                break;
            default:
                System.out.println("Server not found");
                
        }
        }catch(Exception e){
            System.out.println(e);
        }
        return c.getBalance();
    }
    
    

//    @Override
//    public void takeRequest(Client c, String amount) {

//        try {
//            switch (c.getRegion()) {
//                case "Sharm El Sheikh":
//
//                    Registry reg = LocateRegistry.getRegistry("localhost", 1200);
//                    WorkerServer objW = (WorkerServer) reg.lookup("Sharm El Sheikh Worker Server");
//                    switch (request) {
//                        case "Withdraw":
//                            objW.Withdraw(Float.parseFloat(amount));
//                            break;
//                        case "Deposit":
//                            objW.Deposit(Float.parseFloat(amount));
//                            break;
//                        case "Balance":
//                            float b = objW.CheckBalance();
//                    }
//                    break;
//                default:
//                    System.out.println("Region does not exist");
//            }
//
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }

}
