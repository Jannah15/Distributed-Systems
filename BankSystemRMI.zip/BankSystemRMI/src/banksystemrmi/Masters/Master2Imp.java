/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banksystemrmi.Masters;

import Workers.WorkerServer;
import banksystemrmi.ClientSide.Client;
import static banksystemrmi.Masters.Master1Imp.clients1;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author Jannah
 */
public class Master2Imp extends UnicastRemoteObject implements MasterServer {

    public static ArrayList<Client> clients2;
    public static ArrayList<Client> clients1Copy;
    //static Master1GUI m2GUI;

    public Master2Imp() throws RemoteException {
        clients2 = new ArrayList<>();
        clients2.add(new Client("Noha", "14748266", "3456", "New Cairo", 20000));
        clients2.add(new Client("Emad", "15369947", "6789", "Nasr City", 15000));
        clients2.add(new Client("Mohamed", "19134578", "8910", "El Sherouk", 35000));
        clients1Copy = clients1;

    }

    @Override
    public Client getClient(String name, String PIN) throws RemoteException {
        for (int i = 0; i < clients2.size(); i++) {
            Client c1 = clients2.get(i);
            if (c1.getUsername().equals(name) && c1.getPin().equals(PIN)) {
                return c1;
            }
        }
        return null;

    }

    @Override
    public Client deposit(Client c, float amount) throws RemoteException {
        String region = c.getRegion();
        Registry r;
        WorkerServer obj;
        try {
            switch (region) {
                case "El Sherouk":
                    r = LocateRegistry.getRegistry("localhost", 1600);
                    obj = (WorkerServer) r.lookup("El Sherouk Worker Server");
                    c = obj.Deposit(amount);
                    break;
                case "New Cairo":
                    r = LocateRegistry.getRegistry("localhost", 1300);
                    obj = (WorkerServer) r.lookup("New Cairo Worker Server");
                    c = obj.Deposit(amount);
                    break;
                case "Nasr City":
                    r = LocateRegistry.getRegistry("localhost", 1500);
                    obj = (WorkerServer) r.lookup("Nasr City Worker Server");
                    c = obj.Deposit(amount);
                    break;
                default:
                    System.out.println("Server not found");

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return c;
    }

    @Override
    public Client withdraw(Client c, float amount) throws RemoteException {
        String region = c.getRegion();
        Registry r;
        WorkerServer obj;
        try {
            switch (region) {
                case "El Sherouk":
                    r = LocateRegistry.getRegistry("localhost", 1600);
                    obj = (WorkerServer) r.lookup("El Sherouk Worker Server");
                    c = obj.Withdraw(amount);
                    break;
                case "New Cairo":
                    r = LocateRegistry.getRegistry("localhost", 1300);
                    obj = (WorkerServer) r.lookup("New Cairo Worker Server");
                    c = obj.Withdraw(amount);
                    break;
                case "Nasr City":
                    r = LocateRegistry.getRegistry("localhost", 1500);
                    obj = (WorkerServer) r.lookup("Nasr City Worker Server");
                    c= obj.Withdraw(amount);
                    break;
                default:
                    System.out.println("Server not found");

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return c;
    }

    public float checkBalance(Client c) throws RemoteException {
        String region = c.getRegion();
        Registry r;
        WorkerServer obj;
        float b;
        try {
            switch (region) {
                case "El Sherouk":
                    r = LocateRegistry.getRegistry("localhost", 1600);
                    obj = (WorkerServer) r.lookup("El Sherouk Worker Server");
                    b = obj.CheckBalance();
                    break;
                case "New Cairo":
                    r = LocateRegistry.getRegistry("localhost", 1300);
                    obj = (WorkerServer) r.lookup("New Cairo Worker Server");
                    b = obj.CheckBalance();
                    break;
                case "Nasr City":
                    r = LocateRegistry.getRegistry("localhost", 1500);
                    obj = (WorkerServer) r.lookup("Nasr City Worker Server");
                    b = obj.CheckBalance();
                    break;
                default:
                    System.out.println("Server not found");

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return c.getBalance();
    }

    
    
//    @Override
//    public void takeRequest(Client c, String amount) {
//        switch (c.getRegion()) {
//            case "Sharm El Sheikh":
//                try {
//                Registry r = LocateRegistry.getRegistry("localhost", 1200);
//            } catch (Exception e) {
//                System.out.println(e);
//            }
//                break;
//            default:
//                System.out.println("Region does not exist");
//        }
//    }
}
