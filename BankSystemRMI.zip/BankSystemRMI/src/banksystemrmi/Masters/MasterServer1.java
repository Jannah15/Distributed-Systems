/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banksystemrmi.Masters;

import banksystemrmi.ClientSide.BankClient_GUI;
import static banksystemrmi.ClientSide.BankClient_GUI.client;
import banksystemrmi.ClientSide.Client;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Jannah
 */
public class MasterServer1 {

    static Master1_GUI mGUI;

    public static void main(String[] args) throws Exception {

        Registry r = LocateRegistry.createRegistry(1099);

        Master1Imp m1 = new Master1Imp();

        r.rebind("Master Server 1", m1);
        System.out.println("Master Server 1 Connected");

//        mGUI = new Master1_GUI();
//        mGUI.setVisible(true);
        
//String region = client.getRegion();
    }
}
