/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package banksystemrmi.Masters;

import banksystemrmi.ClientSide.Client;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Jannah
 */
public interface MasterServer extends Remote{
    public Client getClient(String name, String PIN) throws RemoteException;
    //public void takeRequest(Client c, String amount) throws RemoteException;
    public Client deposit(Client c, float amount)throws RemoteException;
    public Client withdraw(Client c, float amount)throws RemoteException;
    public float checkBalance(Client c)throws RemoteException;
}
