/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Workers;

import banksystemrmi.ClientSide.Client;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author Jannah
 */
public class Ghurgada extends UnicastRemoteObject implements WorkerServer{

    public static ArrayList<Client> GhurgadaClients;

    public Ghurgada() throws RemoteException {
        GhurgadaClients = new ArrayList<>();
        GhurgadaClients.add(new Client("Noha", "14748266", "3456", "New Cairo", 20000));
    }
    
    @Override
    public Client Withdraw(float amount) throws RemoteException{
       Client c = GhurgadaClients.get(0);
       float balance = c.getBalance() - amount;
       c.setBalance(balance);
       GhurgadaClients.set(0, c);
       System.out.println("Amount Withdrawn: " + amount);
       return GhurgadaClients.get(0);
    }
    
    @Override
    public Client Deposit(float amount) throws RemoteException{
       Client c = GhurgadaClients.get(0);
       float balance = c.getBalance() + amount;
       c.setBalance(balance);
       GhurgadaClients.set(0, c);
       System.out.println("Amount Deposited: " + amount);
       return GhurgadaClients.get(0);
    }
    
    @Override
    public float CheckBalance() throws RemoteException{
       Client c = GhurgadaClients.get(0);
       System.out.println("Balance: " + c.getBalance());
       return c.getBalance(); 
    }
}
