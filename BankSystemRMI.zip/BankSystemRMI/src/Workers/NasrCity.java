/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Workers;

import banksystemrmi.ClientSide.Client;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 *
 * @author Jannah
 */
public class NasrCity extends UnicastRemoteObject implements WorkerServer{

    public static ArrayList<Client> NasrClients;

    public NasrCity() throws RemoteException {
        NasrClients = new ArrayList<>();
        NasrClients.add(new Client("Ahmed", "10349706", "1234", "Sharm El Sheikh", 20000));
    }
    
    @Override
    public Client Withdraw(float amount) throws RemoteException{
       Client c = NasrClients.get(0);
       float balance = c.getBalance() - amount;
       c.setBalance(balance);
       NasrClients.set(0, c);
       System.out.println("Amount Withdrawn: " + amount);
       return NasrClients.get(0);
    }
    
    @Override
    public Client Deposit(float amount) throws RemoteException{
       Client c = NasrClients.get(0);
       float balance = c.getBalance() + amount;
       c.setBalance(balance);
       NasrClients.set(0, c);
       System.out.println("Amount Deposited: " + amount);
       return NasrClients.get(0);
    }
    
    @Override
    public float CheckBalance() throws RemoteException{
       Client c = NasrClients.get(0);
       System.out.println("Balance: " + c.getBalance());
       return c.getBalance(); 
    }
}
