/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Workers;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Jannah
 */
public class GhurgadaServer {
    public static void main(String[] args) throws Exception {
        Ghurgada w = new Ghurgada();
        Registry r = LocateRegistry.createRegistry(1400);
        r.rebind("Ghurgada Worker Server", w);

        System.out.println("Ghurgada Worker Server started");
    }
}
