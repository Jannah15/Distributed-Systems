/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Workers;

import banksystemrmi.ClientSide.Client;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Jannah
 */
public interface WorkerServer extends Remote{
    public Client Withdraw(float amount) throws RemoteException;
    public Client Deposit(float amount) throws RemoteException;
    public float CheckBalance() throws RemoteException;
}
