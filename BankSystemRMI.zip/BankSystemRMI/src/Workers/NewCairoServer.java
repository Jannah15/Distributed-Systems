/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Workers;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Jannah
 */
public class NewCairoServer {
    public static void main(String[] args) throws Exception {
        NewCairo w = new NewCairo();
        Registry r = LocateRegistry.createRegistry(1300);
        r.rebind("New Cairo Worker Server", w);

        System.out.println("New Cairo Server started");
    }
}
