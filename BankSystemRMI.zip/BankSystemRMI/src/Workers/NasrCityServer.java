/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Workers;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Jannah
 */
public class NasrCityServer {
    public static void main(String[] args) throws Exception {
        NasrCity w = new NasrCity();
        Registry r = LocateRegistry.createRegistry(1500);
        r.rebind("Nasr City Worker Server", w);

        System.out.println("Nasr City Worker Server started");
    }
}
