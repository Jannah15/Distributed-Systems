/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p2p_project;

import java.io.Serializable;

/**
 *
 * @author Jannah
 */
public class P2PClient implements Serializable{
    String username;
    int Port;

    public P2PClient(String username, int Port) {
        this.username = username;
        this.Port = Port;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getPort() {
        return Port;
    }

    public void setPort(int Port) {
        this.Port = Port;
    }

    @Override
    public String toString() {
        return "user{" + "username=" + username + ", Port=" + Port + '}';
    }
}
