/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p2p_project;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author Jannah
 */
public class Coordinator implements Runnable {

    Socket cSocket;
    static ArrayList<P2PClient> clients = new ArrayList<>();
    static CoordinatorGUI CoGUI;

    public Coordinator(Socket cSocket) {
        this.cSocket = cSocket;

    }

    @Override
    public void run() {
        try {
            ObjectOutputStream out = new ObjectOutputStream(cSocket.getOutputStream());
            ObjectInputStream input = new ObjectInputStream(cSocket.getInputStream());
            P2PClient c = (P2PClient) input.readObject();

            clients.add(c);

            System.out.println(c.username + " is connected.");
            CoGUI.appendTextArea(c.username + " is connected.");

            System.out.println(clients);

            Message m = (Message) input.readObject();
            CoGUI.appendTextArea(m.msg + "\n");
            for (P2PClient client : clients) {
                Socket s = new Socket("localhost", client.Port);
                ObjectOutputStream output = new ObjectOutputStream(s.getOutputStream());
                output.writeObject(m);
            }

            input.close();
            out.close();

//            cSocket.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) throws IOException {
        ServerSocket sSocket = new ServerSocket(3000);
        CoGUI = new CoordinatorGUI();
        CoGUI.setVisible(true);
        System.out.println("Listening");
        while (true) {
            Socket S = sSocket.accept();
            System.out.println("Connected");
            Thread Client = new Thread(new Coordinator(S));
            Client.start();
        }
    }
}
