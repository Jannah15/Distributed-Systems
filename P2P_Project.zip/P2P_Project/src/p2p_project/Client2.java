/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p2p_project;

import java.io.DataInputStream;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import static p2p_project.Client1.cGUI;
import static p2p_project.Client1GUI.decrypt;
import static p2p_project.Coordinator.CoGUI;

/**
 *
 * @author Jannah
 */
public class Client2 implements Runnable{
    Socket cSocket;
    static Client2GUI cGUI;
    
    static ArrayList<P2PClient> clients = new ArrayList<>();

    public Client2(Socket cSocket) {
        this.cSocket = cSocket;
    }

    @Override
    public void run() {
        try {
            //ObjectInputStream input = new ObjectInputStream(cSocket.getInputStream());
            //clients = (ArrayList)input.readObject();
            
            //input.close();
//            String msg = m.getMsg();
//            System.out.println(msg);

            //System.out.println(clients);
            
            
//            DataInputStream in = new DataInputStream(cSocket.getInputStream());
//            String msg = in.readUTF();
//            System.out.println(msg);
//            cGUI.appendTextArea(msg);
//            CoGUI.appendTextArea(msg);
            
            
            ObjectInputStream in = new ObjectInputStream(cSocket.getInputStream());
            Message mes = (Message)in.readObject();
            if(mes.receiver == 4000){
            String msg = decrypt(mes.msg);
                System.out.println(msg);
//            CoGUI.appendTextArea(mes.msg);
                
                cGUI.appendTextArea(msg);
            }
            

//            input.close();
            in.close();
//            cSocket.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        cGUI = new Client2GUI();
        cGUI.setVisible(true);
        
        try {
            ServerSocket sSocket = new ServerSocket(4000);
            System.out.println("Listening");
            while (true) {
                Socket S = sSocket.accept();
                Thread Client = new Thread(new Client2(S));
                Client.start();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    
}
